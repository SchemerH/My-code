﻿namespace _8
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.用户管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增学生用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增教师用户ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询修改ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.用户列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.题库管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.考试管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.用户管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.新增用户ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.新增学生ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增教师ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.信息列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dGV显示ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.题库管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.考试管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // 用户管理ToolStripMenuItem
            // 
            this.用户管理ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新增用户ToolStripMenuItem,
            this.查询修改ToolStripMenuItem,
            this.用户列表ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this.用户管理ToolStripMenuItem.Name = "用户管理ToolStripMenuItem";
            this.用户管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.用户管理ToolStripMenuItem.Text = "用户管理";
            // 
            // 新增用户ToolStripMenuItem
            // 
            this.新增用户ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新增学生用户ToolStripMenuItem,
            this.新增教师用户ToolStripMenuItem});
            this.新增用户ToolStripMenuItem.Name = "新增用户ToolStripMenuItem";
            this.新增用户ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.新增用户ToolStripMenuItem.Text = "新增用户";
            // 
            // 新增学生用户ToolStripMenuItem
            // 
            this.新增学生用户ToolStripMenuItem.Name = "新增学生用户ToolStripMenuItem";
            this.新增学生用户ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.新增学生用户ToolStripMenuItem.Text = "新增学生用户";
            // 
            // 新增教师用户ToolStripMenuItem
            // 
            this.新增教师用户ToolStripMenuItem.Name = "新增教师用户ToolStripMenuItem";
            this.新增教师用户ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.新增教师用户ToolStripMenuItem.Text = "新增教师用户";
            // 
            // 查询修改ToolStripMenuItem
            // 
            this.查询修改ToolStripMenuItem.Name = "查询修改ToolStripMenuItem";
            this.查询修改ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.查询修改ToolStripMenuItem.Text = "查询修改";
            // 
            // 用户列表ToolStripMenuItem
            // 
            this.用户列表ToolStripMenuItem.Name = "用户列表ToolStripMenuItem";
            this.用户列表ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.用户列表ToolStripMenuItem.Text = "用户列表";
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            // 
            // 题库管理ToolStripMenuItem
            // 
            this.题库管理ToolStripMenuItem.Name = "题库管理ToolStripMenuItem";
            this.题库管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.题库管理ToolStripMenuItem.Text = "题库管理";
            // 
            // 考试管理ToolStripMenuItem
            // 
            this.考试管理ToolStripMenuItem.Name = "考试管理ToolStripMenuItem";
            this.考试管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.考试管理ToolStripMenuItem.Text = "考试管理";
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.关于ToolStripMenuItem.Text = "关于";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.用户管理ToolStripMenuItem1,
            this.题库管理ToolStripMenuItem1,
            this.考试管理ToolStripMenuItem1,
            this.关于ToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(537, 25);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 用户管理ToolStripMenuItem1
            // 
            this.用户管理ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新增用户ToolStripMenuItem1,
            this.修改查询ToolStripMenuItem,
            this.信息列表ToolStripMenuItem,
            this.退出ToolStripMenuItem1});
            this.用户管理ToolStripMenuItem1.Name = "用户管理ToolStripMenuItem1";
            this.用户管理ToolStripMenuItem1.Size = new System.Drawing.Size(68, 21);
            this.用户管理ToolStripMenuItem1.Text = "用户管理";
            // 
            // 新增用户ToolStripMenuItem1
            // 
            this.新增用户ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新增学生ToolStripMenuItem,
            this.新增教师ToolStripMenuItem});
            this.新增用户ToolStripMenuItem1.Name = "新增用户ToolStripMenuItem1";
            this.新增用户ToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.新增用户ToolStripMenuItem1.Text = "新增用户";
            // 
            // 新增学生ToolStripMenuItem
            // 
            this.新增学生ToolStripMenuItem.Name = "新增学生ToolStripMenuItem";
            this.新增学生ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.新增学生ToolStripMenuItem.Text = "新增学生";
            this.新增学生ToolStripMenuItem.Click += new System.EventHandler(this.新增学生ToolStripMenuItem_Click);
            // 
            // 新增教师ToolStripMenuItem
            // 
            this.新增教师ToolStripMenuItem.Name = "新增教师ToolStripMenuItem";
            this.新增教师ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.新增教师ToolStripMenuItem.Text = "新增教师";
            // 
            // 修改查询ToolStripMenuItem
            // 
            this.修改查询ToolStripMenuItem.Name = "修改查询ToolStripMenuItem";
            this.修改查询ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.修改查询ToolStripMenuItem.Text = "修改查询";
            this.修改查询ToolStripMenuItem.Click += new System.EventHandler(this.修改查询ToolStripMenuItem_Click);
            // 
            // 信息列表ToolStripMenuItem
            // 
            this.信息列表ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dGV显示ToolStripMenuItem});
            this.信息列表ToolStripMenuItem.Name = "信息列表ToolStripMenuItem";
            this.信息列表ToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.信息列表ToolStripMenuItem.Text = "信息列表";
            this.信息列表ToolStripMenuItem.Click += new System.EventHandler(this.信息列表ToolStripMenuItem_Click);
            // 
            // dGV显示ToolStripMenuItem
            // 
            this.dGV显示ToolStripMenuItem.Name = "dGV显示ToolStripMenuItem";
            this.dGV显示ToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.dGV显示ToolStripMenuItem.Text = "DGV显示";
            this.dGV显示ToolStripMenuItem.Click += new System.EventHandler(this.dGV显示ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem1
            // 
            this.退出ToolStripMenuItem1.Name = "退出ToolStripMenuItem1";
            this.退出ToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.退出ToolStripMenuItem1.Text = "退出";
            this.退出ToolStripMenuItem1.Click += new System.EventHandler(this.退出ToolStripMenuItem1_Click_1);
            // 
            // 题库管理ToolStripMenuItem1
            // 
            this.题库管理ToolStripMenuItem1.Name = "题库管理ToolStripMenuItem1";
            this.题库管理ToolStripMenuItem1.Size = new System.Drawing.Size(68, 21);
            this.题库管理ToolStripMenuItem1.Text = "题库管理";
            // 
            // 考试管理ToolStripMenuItem1
            // 
            this.考试管理ToolStripMenuItem1.Name = "考试管理ToolStripMenuItem1";
            this.考试管理ToolStripMenuItem1.Size = new System.Drawing.Size(68, 21);
            this.考试管理ToolStripMenuItem1.Text = "考试管理";
            // 
            // 关于ToolStripMenuItem1
            // 
            this.关于ToolStripMenuItem1.Name = "关于ToolStripMenuItem1";
            this.关于ToolStripMenuItem1.Size = new System.Drawing.Size(44, 21);
            this.关于ToolStripMenuItem1.Text = "关于";
            this.关于ToolStripMenuItem1.Click += new System.EventHandler(this.关于ToolStripMenuItem1_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel6});
            this.statusStrip1.Location = new System.Drawing.Point(0, 301);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(537, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "当前用户";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(56, 17);
            this.toolStripStatusLabel1.Text = "当前用户";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(0, 17);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 323);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.Name = "Form2";
            this.Text = "管理员";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem 用户管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新增用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新增学生用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新增教师用户ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询修改ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 用户列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 题库管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 考试管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 用户管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 新增用户ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 新增学生ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新增教师ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 信息列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 题库管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 考试管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripMenuItem dGV显示ToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
    }
}